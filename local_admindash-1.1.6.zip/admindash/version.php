<?php
defined('MOODLE_INTERNAL') || die();
$plugin = new stdClass();
$plugin->component = 'local_admindash';
$plugin->version   = 2025092306;
$plugin->release   = '1.1.6';
$plugin->requires  = 2022041900;
$plugin->maturity  = MATURITY_STABLE;
